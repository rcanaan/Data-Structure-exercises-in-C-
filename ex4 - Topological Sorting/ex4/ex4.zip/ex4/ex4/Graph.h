#include <iostream>
#include <string>
#include <list>
#include "Vertex.h"
#define maxSize 100

#pragma once
class Graph
{
	//Vertex * graph[maxSize];
	list <Vertex *> order;//the list from dfs
	int timer;//definding time
	std::map<string, Vertex*> graph;

public:
	Graph()//constructor
	{
		timer = 0;
	}
	~Graph()
	{
		for (map<string, Vertex*>::iterator it = graph.begin(); it != graph.end(); it++)
		{
			(*it).second->RemoveEdges();
		}
		for (map<string, Vertex*>::iterator it = graph.begin(); it != graph.end(); it++)
		{
			delete(*it).second;
		}

		graph.clear();

	}
	bool add_Edge(string& fKey, string& sKey)
	{
		if (graph.find(fKey) == graph.end() || graph.find(sKey) == graph.end()) //one of the keys was not found we cannot add an edge
		{
			return false;
		}
		Vertex* v1 = graph[fKey]; //new Vertex(key1);
		Vertex* v2 = graph[sKey]; //new Vertex(key2);
		if (v1->DestinationExists(v2))//checks if the edge already exists
			return false;
		//the edge does not exist so it creates a new Edge with v1 and v2
		v1->addEdge(new Edge(v2));
		return true;
	}
	bool add_Vertex(string & k)
	{
		map<string, Vertex*>::iterator it;//iterator to the map
		if (graph.empty() || graph.find(k) == graph.end())//if the vertex does not exist we will create a new one and add it to the map
		{
			graph[k] = new Vertex(k);
			return true;//if it was added successfully
		}
		else
		{
			return false; //vertex already exist
		}
	}

	list<Vertex*> DFS()
	{
		timer = 0;
		order.clear();
		map<string, Vertex*>::iterator it;
		for (it = graph.begin(); it != graph.end(); it++)
		{
			(*it).second->initialize();//initialize all the vertexes
		}

		for (it = graph.begin(); it != graph.end(); it++)
		{
			Vertex *v = (*it).second;
			if (v->color == white)
			{
				DFS_visit(v);
			}
		}
		return order;//returns the order of the tasks
	}

	void DFS_visit(Vertex * a)
	{
		a->color = gray;
		timer++;
		a->d = timer;
		list<Edge*>::iterator it;
		for (it = a->neighborsList.begin(); it != a->neighborsList.end(); it++)
		{
			Vertex *v = (*it)->destination;
			if (v->color == white)
			{//we h
				v->pi = a;
				DFS_visit(v);
			}
		}
		a->color = black;
		timer++;
		a->f = timer;
		order.push_front(a);
	}

	void printAll()
	{
		map<string, Vertex*>::iterator it;
		for (it = graph.begin(); it != graph.end(); it++)
		{
			(*it).second->print();
			cout << endl;
		}
	}

	void printPath(Vertex *v1, Vertex *v2)
	{

		if (v1 == v2)
			cout << v1->Key;
		if (!(v2->pi))
			return;
		else
		{
			printPath(v1, v2->pi);
			cout << "->" << v2->Key;
		}
	}
	

	void topoligicalSort()
	{
		DFS();
		std::cout << "order: ";
	
		for (list<Vertex*>::iterator it = order.begin(); it != order.end(); it++)
		{
			cout << (*it)->Key << " ";
		}
	}
};