#include <iostream>
#include <string>
#include <list>
#include <queue>
#include <map>
using namespace std;
class Vertex;

#pragma once
enum Color
{
	black,
	gray,
	white
};

#pragma region Edge
class Vertex;
class Edge//order between tasks
{
private:
	//Vertex* source;
	Vertex* destination;
	//int dis;//for distance between the edges
public:
	friend class Vertex;
	friend class Graph;
	//Edge(Vertex* s = NULL, Vertex* d = NULL, int my_dis = 0);
	//bool operator ==(const Edge& e) const;
	Edge(Vertex * v)
	{
		destination = v;
	}
	bool operator ==(const Edge& e) const
	{
		return(destination == e.destination);
	}

#pragma endregion



};




#pragma region Vertex
class Edge;
class Vertex//task
{
	//fields
private:
	Color color;
	int d;//starting 
	int f;//finishing
	list <Edge *> neighborsList;//neighbors list
	string Key;
	Vertex * pi;//point to the father

	//methods
public:
	friend class Graph;
	friend class Edge;
	//implementions:
	void  initialize()
	{
		color = white;
		pi = NULL;
	}
	Vertex(string k = NULL)
	{
		initialize();
		Key = k;
	}

	void addEdge(Edge* v)
	{
		neighborsList.push_back(v);
	}
	int NumOfNeighbors()
	{
		//return neighborsList.size();
		int count = 0;
		//a loop that counts how many edges there are to this vertex
		for (list<Edge*>::iterator it = neighborsList.begin(); it != neighborsList.end(); it++)
			count++;
		return count;
	}
	/*friend ostream& operator<<(ostream& os, const Vertex& v)
	{
		cout << "Main key: " << v.Key << endl;
		cout << "neighbors: " << endl;
		for (list<Edge *>::iterator it = v.neighborsList.begin(); it != v.neighborsList.end(); it++)
		{
			cout << "key: " << v.Key << endl;
		}
		return os;
	}*/
	void RemoveEdges()//maybe for a specific vertex?
	{
		for (list<Edge *>::iterator it = neighborsList.begin(); it != neighborsList.end(); it++)
		{
			delete (*it);
		}
	}
	void print()
	{
		cout << Key << ": ";
		list<Edge *>::iterator it;
		for (it = neighborsList.begin(); it != neighborsList.end(); it++)
			cout << ((*it)->destination)->Key << " ";
	}
	friend class Edge;
	bool DestinationExists(Vertex* v)
	{
		/*for (list<Edge *>::iterator it = v->neighborsList.begin(); it != v->neighborsList.end(); it++)
		{
		
			if ((*it)->destination == v)
				return true;
		}
		return false;*/
	

		list<Edge *>::iterator it = neighborsList.begin();
		for (; it != neighborsList.end(); it++)
			if ((*it)->destination == v)//if the vertex exists returns true, else return false
				return true;
		return false;
	}
	bool operator ==(const Vertex& v) const
	{
		if (this->Key == v.Key)
			return true;
		return false;
	}











};
#pragma endregion

